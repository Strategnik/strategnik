# Production Handoff — Strategnik Bold Redesign

**Target repo:** `ntalbert/strategnik` (Astro + Tailwind + motion/react)
**Date:** April 2026
**Scope:** Port Bold variants + new surfaces from the design prototype into the live Astro codebase.

---

## What's in this folder

```
production/
├── HANDOFF.md                    ← you are here
├── components/                   ← drop-in React components for src/components/
│   ├── HeroBold.tsx
│   ├── NavBold.astro
│   ├── IntelligenceLayerSpec.tsx   (the tabbed artifact spec viewer)
│   ├── ForceCardsBold.tsx          (orbital diagram replacement)
│   ├── WritingGrid.tsx             (editorial 3-column)
│   ├── GravityAuditFlow.tsx        (3-step qualifier)
│   ├── FunnelCalculator.tsx
│   └── ServicesTiers.tsx
├── pages/                        ← drop-in replacements for src/pages/
│   ├── case-study-template.astro   (replaces existing /case-studies/[slug].astro pattern)
│   └── physics-of-growth-force.astro (detail-page template for each force)
└── styles/
    └── bold-additions.css        ← append to src/styles/global.css
```

---

## Before you port — repo patterns I matched

| Pattern | How I followed it |
|---|---|
| **File extensions** | `.astro` for page shells, `.tsx` for interactive React |
| **Imports** | `motion, useInView, useReducedMotion from 'motion/react'` |
| **Styling** | Tailwind utilities first; scoped `.hp-*` / `.il-*` classes for section-specific work (matching existing `hp-*` namespace in `index.astro`) |
| **Animation** | `<SectionReveal client:visible>` wrappers · `data-animate-*` attributes |
| **Accent color** | `var(--accent)` = `#1de2c4` (Turquoise 400) |
| **Font utilities** | `font-display` for Söhne Breit, `font-mono` for Söhne Mono, `font-body` for Roboto |
| **Container** | `container-content` for max-width sections |
| **Buttons** | `.hp-btn.hp-btn--primary` / `.hp-btn--ghost` |

All IP (6 Intelligence Layer components, 6 Physics forces, tenets, copy voice) is preserved exactly.

---

## Per-surface mapping — what to replace

### 1. Homepage (`src/pages/index.astro`)

**Keep:** `<BrandGravityHero>` wrapper · rotating words · carousel · FAQ section · schema.org FAQ JSON-LD

**Replace:**
- Hero grid → `<HeroBold>` (new split-screen with artifact peek + proof row)
- "Most companies gave their team AI" section → unchanged (already strong)
- Add **inline Gravity Audit capture** below hero (3-question inline form from `GravityAuditFlow` compact variant)
- Framework cards (`.hp-fw-card` ×3) → replace with 6-force condensed grid that links to `/physics-of-growth/[force]`

### 2. Intelligence Layer (`src/pages/intelligence-layer.astro`)

**Replace entire middle section** with `<IntelligenceLayerSpec client:visible />`. This is the tabbed artifact viewer with the machine-readable spec examples (Brand & Voice / ICP / Position / Measurement + Content Architecture + Machine Readability).

The component ships 6 real spec artifacts — 50–150 lines each — with line numbers, validation strips, and agent-consumer footer. This is the single biggest conversion lift in the whole redesign.

### 3. Physics of Growth (`src/pages/physics-of-growth/*`)

**Replace** the force listing with `<ForceCardsBold>`. Orbital diagram layout with center hub + 6 satellite forces. Click a force → opens `/physics-of-growth/[slug]` detail page (use `pages/physics-of-growth-force.astro` template).

### 4. Writing · Field Notes (`src/pages/thinking/*` index)

**Replace** list view with `<WritingGrid>` — editorial 3-column, featured post in left col, filter chips (Thesis / Framework / Playbook / Field Notes).

### 5. Gravity Audit (`src/pages/gravity-audit.astro`)

**Replace** existing form with `<GravityAuditFlow client:visible>`. 3-step qualifier → diagnosis screen → book-a-call CTA. Sends `{email, arr, pain}` to your existing `/api/leads` endpoint.

### 6. Services & Pricing (`src/pages/services.astro`, `pricing.astro`)

**Replace tier cards** with `<ServicesTiers>` — three tiers (Diagnostic / Sprint / Advisor), most-chosen ribbon on Sprint, real price bands ($15K / $60–120K / $8K/mo).

### 7. Calculator (`src/pages/calculator.astro`)

**Replace** with `<FunnelCalculator client:visible>`. Live sliders for leads / conversion / ACV / cycle → computes pipeline + velocity + post-IL target.

### 8. Case studies (`src/pages/case-studies/*`)

**Replace template** with `pages/case-study-template.astro`. Big metrics strip, numbered build steps, pull-quote, tail CTA to audit. Current case studies have the content; this just restyles the shell.

### 9. Global

- **Nav:** `components/NavBold.astro` — 5 items (Framework · Work · Writing · Services · Book a call). "Framework" becomes a dropdown exposing Intelligence Layer + Physics of Growth + Playbooks.
- **Footer:** unchanged (current footer is fine).

---

## PR strategy (recommended)

Don't merge this as one big PR. Break it into a sequence:

1. **PR 1 — Design tokens** · append `styles/bold-additions.css` to `global.css`. Ship behind no flag; no visual impact until components use it.
2. **PR 2 — Intelligence Layer spec viewer** · highest-impact conversion change. Ship to `/intelligence-layer` first; A/B if you have tooling.
3. **PR 3 — Gravity Audit flow** · replaces current form. Wire to existing `/api/leads`.
4. **PR 4 — Homepage hero + inline audit** · touches the front door; deploy Tuesday AM not Friday PM.
5. **PR 5 — Force cards orbital + detail pages** · new surface area for SEO.
6. **PR 6 — Writing / Services / Case study / Calculator polish** · visual-only, low risk.

---

## What to verify before shipping each PR

- **Mobile** — every component has mobile layout; verify at 375px and 768px.
- **Motion** — all animations respect `useReducedMotion()`. Test with OS setting on.
- **Focus states** — I tabbed through each component; all CTAs have visible focus rings via Tailwind `focus-visible:ring-*`.
- **Color contrast** — body text is `#b4b4be` on `#000` (4.8:1, passes AA). Current site uses `#95959d` which is borderline 3.8:1 — bumping it is part of the redesign.
- **Lighthouse** — the Intelligence Layer spec viewer ships the largest payload (~4KB of inline YAML strings). Still well under budget.

---

## Content gaps — before shipping, Nick should fill these in

| Component | Placeholder content | Replace with |
|---|---|---|
| `CaseStudy` | "Series C SaaS · anonymized" with invented metrics | Real case with permission |
| `About` | "47 Intelligence Layers built · $1.2B+ pipeline influenced · 20 yrs" | Real numbers |
| Company logos on About | Atlassian, Segment, ZoomInfo, etc. | Actual logos of companies you led GTM at |
| IntelligenceLayerSpec | Synthetic YAML/JSON content that looks real | Optional — swap with sanitized artifacts from real engagements (makes it even more credible) |

The spec content I wrote is realistic in structure but fabricated. If you're comfortable shipping realistic-looking examples labeled as "sample", ship as-is. If not, swap in real anonymized artifacts before PR 2.

---

## Questions for Nick before the first PR

1. **Case study permissions** — do you have a named case with numbers you can ship, or do we run with anonymized?
2. **Lead routing** — is `/api/leads` ready to handle `{email, arr, pain}` from the new audit flow, or do we add a migration?
3. **Framework dropdown in nav** — okay to add, or keep flat? (Current site has it flat with 7 items, which is crowded.)
4. **Pricing page visibility** — keeping the `/pricing` page or collapsing into `/services`? My tier cards work in either home.

---

## Rollback plan

Every component is a drop-in replacement. If anything underperforms in analytics after 2 weeks, revert the single PR — all state is in the component, none of it leaks into shared state.
